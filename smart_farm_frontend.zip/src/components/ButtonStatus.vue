<template>
    <div class="button-status">
      <h3>{{ label }}</h3>
      <div class="status-container">
        <span>{{ currentTime }}</span>
        <span>{{ status }}</span>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    name: "ButtonStatus",
    props: {
      label: {
        type: String,
        default: "Button",
      },
    },
    data() {
      return {
        currentTime: new Date().toLocaleTimeString(), // Local time
        states: ["Pressed", "Unpressed"], // Array of possible states
        currentIndex: 0, // Default index for "Pressed"
      };
    },
    computed: {
      status() {
        return this.states[this.currentIndex]; // Dynamically display the current state
      },
    },
    methods: {
      // Update the state externally (e.g., from IoT data)
      updateState(newIndex) {
        if (newIndex >= 0 && newIndex < this.states.length) {
          this.currentIndex = newIndex;
        }
      },
    },
    mounted() {
      // Update the current time every second
      setInterval(() => {
        this.currentTime = new Date().toLocaleTimeString();
      }, 1000);
  
      // Simulate receiving IoT updates for testing (can be removed later)
      setInterval(() => {
        this.currentIndex = this.currentIndex === 0 ? 1 : 0; // Toggle between states
      }, 5000);
    },
  };
  </script>
  
  <style scoped>
  .button-status {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    background-color: #2d6d92; /* Background color */
    color: white;
    border-radius: 8px;
    padding: 20px;
    width: 150px;
    height: 150px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
  }
  
  .status-container {
    display: flex;
    justify-content: space-between;
    width: 100%;
    margin-top: 20px;
    font-weight: bold;
  }
  
  .status-container span:last-child {
    text-transform: uppercase; /* Ensure status is displayed in uppercase */
  }
  </style>
  