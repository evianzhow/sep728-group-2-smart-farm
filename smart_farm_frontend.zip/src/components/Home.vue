<template>
    <div>
      <h1>Main Panel</h1>
      <div class="card-container">
        <SensorCard 
          title="HUMIDITY" 
          value="36.6%" 
          icon="💧" 
          color="blue" />
        <SensorCard 
          title="ILLUMINATION" 
          value="739lm" 
          icon="⚙️" 
          color="red" />
        <SensorCard 
          title="TEMPERATURE" 
          value="21.7°C" 
          icon="🌡️" 
          color="orange" />
      </div>

      <div class="toggle-container">
            <ToggleSwitch label="Passive Buzzer" />
            <ToggleSwitch label="LED" />
            <ToggleSwitch label="Relay Module" />
            <ToggleSwitch label="Button" />
      </div>

      <div class="controls-container">
            <RangeSlider label="Fan" />
            <ButtonStatus label="Button" />
      </div>

    </div>
  </template>
  
  <script>
  import SensorCard from './SensorCard.vue';
  import ToggleSwitch from './ToggleSwitch.vue';
  import RangeSlider from './RangeSlider.vue';
  import ButtonStatus from './ButtonStatus.vue';
  
  export default {
    name: "HomePage",
    components: {
      SensorCard,
      ToggleSwitch,
      RangeSlider,
      ButtonStatus,
    },
  };
  </script>
  
  <style scoped>
  .card-container {
    display: flex;
    gap: 20px;
    margin-top: 20px;
  }

  .toggle-container {
  margin-top: 30px;
  display: flex;
  align-items: flex-start; /* Align switches to the left */
  gap: 20px; /* Add spacing between switches */
}
    .controls-container {
    margin-top: 30px;
    display: flex;
    gap: 20px;
    align-items: flex-start; /* Align switches to the left */
    }
  </style>
  