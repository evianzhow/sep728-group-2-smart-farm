/* eslint-disable */
import { createRouter, createWebHistory } from "vue-router";
import Home from "../components/Home.vue";
import Rules from "../components/Rules.vue";
import Settings from "../components/Settings.vue";
import SensorDetails from "../components/SensorDetails.vue";

const routes = [
  { path: "/", redirect: "/home" },
  { path: "/home", component: Home },
  { path: "/rules", component: Rules },
  { path: "/settings", component: Settings },
  { path: "/sensor/:title", component: SensorDetails },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

export default router;
