<template>
    <div>
      <h1>Main Panel</h1>
      <p>Sensors:</p>
      <div class="card-container">
        <SensorCard 
          title="HUMIDITY" 
          :value="humidityValue + ' %'" 
          icon="💧" 
          color="blue" 
          @dblclick="navigateToDetails('HUMIDITY')"/>
        <SensorCard 
          title="ILLUMINATION" 
          :value="illuminationValue + ' %'" 
          icon="🌞" 
          color="red" 
          @dblclick="navigateToDetails('ILLUMINATION')"/>
        <SensorCard 
          title="TEMPERATURE" 
          :value="temperatureValue1 + ' C° / ' + temperatureValue2 + ' F° / ' + temperatureValue3 + ' k°'" 
          icon="🌡️" 
          color="orange" 
          @dblclick="navigateToDetails('TEMPERATURE')"/>
        <SensorCard 
          title="STEAM" 
          :value="steamValue + ' %'" 
          icon="🌤️" 
          color="blue" 
          @dblclick="navigateToDetails('STEAM')"/>
        <SensorCard 
          title="DEWPOINT" 
          :value="dewPointValue + ' C°'" 
          icon="💦" 
          color="red" 
          @dblclick="navigateToDetails('DEWPOINT')"/>
        <SensorCard 
          title="SOILHUMADITY" 
          :value="soilHumadityValue + ' %'" 
          icon="🌱" 
          color="orange" 
          @dblclick="navigateToDetails('SOILHUMADITY')"/>
        <SensorCard 
          title="WATERLEVEL" 
          :value="WaternValue + ' cm'" 
          icon="🌊" 
          color="blue" 
          @dblclick="navigateToDetails('WATERLEVEL')"/>
        <SensorCard 
          title="ULTRASONIC" 
          :value="ultrasonicValue + ' cm'" 
          icon="🔊" 
          color="red" 
          @dblclick="navigateToDetails('ULTRASONIC')"/>
        <SensorCard 
          title="PHOTORESISTOE" 
          value="65" 
          icon="📷" 
          color="orange" 
          @dblclick="navigateToDetails('PHOTORESISTOE')"/>
      </div>

      <p>Controllers:</p>
      <div class="toggle-container">
            <ToggleSwitch label="Passive Buzzer" />
            <ToggleSwitch label="LED" />
            <ToggleSwitch label="Relay Module" />
            <ToggleSwitch label="Servo" />
      </div>

      <div class="controls-container">
            <RangeSlider label="Fan" />
            <ButtonStatus label="Button" />
            <ButtonStatus label="PIR" />
      </div>

    </div>
  </template>
  
  <script>
  import SensorCard from './SensorCard.vue';
  import ToggleSwitch from './ToggleSwitch.vue';
  import RangeSlider from './RangeSlider.vue';
  import ButtonStatus from './ButtonStatus.vue';
  import axios from "axios";
  
  export default {
    name: "HomePage",
    components: {
      SensorCard,
      ToggleSwitch,
      RangeSlider,
      ButtonStatus,
    },
    inject: ["getAuthToken"],
    data() {
    return {
      authToken: "",
      illuminationValue: "Loading...", 
      WaternValue: "Loading...",
      steamValue: "Loading...",
      ultrasonicValue: "Loading...",
      temperatureValue1: "Loading...",
      temperatureValue2: "Loading...",
      temperatureValue3: "Loading...",
      humidityValue: "Loading...",
      dewPointValue: "Loading...",
      soilHumadityValue: "Loading...",
    };
  },
    methods: {
      navigateToDetails(title) {
      this.$router.push(`/sensor/${title}`); // Navigate to the sensor details page
    },
    //---------------Here to use API------------------------------
    //Soil humadity
    async fetchSoilHumadityValue() {
      try {
        const token = this.getAuthToken(); 
        console.log("Token being used:", token); 
        const response = await axios.get(
          "https://gorgeous-glowworm-definite.ngrok-free.app/sensors/soil/preview",
          {
            headers: {
              Authorization: token, 
            },
          }
        );
        console.log("Response data:", response.data);
        this.soilHumadityValue = response.data.percentage; 
      } catch (error) {
        console.error("Error fetching soil humidity data:", error); 
        this.soilHumadityValue = "Error";
      }
    },
    //Dew Point
    async fetchDewPointValue() {
      try {
        const token = this.getAuthToken(); 
        console.log("Token being used:", token); 
        const response = await axios.get(
          "https://gorgeous-glowworm-definite.ngrok-free.app/sensors/dht11/dewpoint/preview",
          {
            headers: {
              Authorization: token, 
            },
          }
        );
        console.log("Response data:", response.data);
        this.dewPointValue = response.data.dewpoint.celsius; 
      } catch (error) {
        console.error("Error fetching dew point data:", error); 
        this.dewPointValue = "Error";
      }
    },
    //Humamidity
    async fetchHumidityValue() {
      try {
        const token = this.getAuthToken(); 
        console.log("Token being used:", token); 
        const response = await axios.get(
          "https://gorgeous-glowworm-definite.ngrok-free.app/sensors/dht11/humidity/preview",
          {
            headers: {
              Authorization: token, 
            },
          }
        );
        console.log("Response data:", response.data);
        this.humidityValue = response.data.humidity.value; 
      } catch (error) {
        console.error("Error fetching humidity data:", error); 
        this.humidityValue = "Error";
      }
    },
    //Illumination
        async fetchIlluminationValue() {
      try {
        const token = this.getAuthToken(); 
        console.log("Token being used:", token); 
        const response = await axios.get(
          "https://gorgeous-glowworm-definite.ngrok-free.app/sensors/light/preview",
          {
            headers: {
              Authorization: token, 
            },
          }
        );
        console.log("Response data:", response.data);
        this.illuminationValue = response.data.percentage; 
      } catch (error) {
        console.error("Error fetching illumination data:", error); 
        this.illuminationValue = "Error";
      }
    },
    //Water
    async fetchWaterValue() {
      try {
        const token = this.getAuthToken(); 
        const response = await axios.get(
          "https://gorgeous-glowworm-definite.ngrok-free.app/sensors/water/preview",
          {
            headers: {
              Authorization: token, 
            },
          }
        );
        this.WaternValue = response.data.value; 
      } catch (error) {
        console.error("Error fetching water data:", error);
        this.WaternValue = "Error"; 
      }
    },
    //Steam
    async fetchSteamValue() {
      try {
        const token = this.getAuthToken(); 
        const response = await axios.get(
          "https://gorgeous-glowworm-definite.ngrok-free.app/sensors/steam/preview",
          {
            headers: {
              Authorization: token, 
            },
          }
        );
        this.steamValue = response.data.value; 
      } catch (error) {
        console.error("Error fetching steam data:", error);
        this.steamValue = "Error"; 
      }
    },
    //ultrasonic
    async fetchUltrasonicValue() {
      try {
        const token = this.getAuthToken(); 
        const response = await axios.get(
          "https://gorgeous-glowworm-definite.ngrok-free.app/sensors/ultrasonic/preview",
          {
            headers: {
              Authorization: token, 
            },
          }
        );
        this.ultrasonicValue = response.data.value; 
      } catch (error) {
        console.error("Error fetching ultrasonic data:", error);
        this.ultrasonicValue = "Error"; 
      }
    },
    //temperature
    async fetchTemperatureValue() {
      try {
        const token = this.getAuthToken(); 
        const response = await axios.get(
          "https://gorgeous-glowworm-definite.ngrok-free.app/sensors/dht11/temperature/preview",
          {
            headers: {
              Authorization: token, 
            },
          }
        );
        this.temperatureValue1 = response.data.temperature.celsius; 
        this.temperatureValue2 = response.data.temperature.fahrenheit;
        this.temperatureValue3 = response.data.temperature.kelvin;
      } catch (error) {
        console.error("Error fetching ultrasonic data:", error);
        this.temperatureValue1 = "Error"; 
        this.temperatureValue2 = "Error"; 
        this.temperatureValue3 = "Error"; 
      }
    },
    //------------------------------------------------------------
    },
    async mounted() {
        await this.fetchIlluminationValue(); 
        await this.fetchWaterValue();
        await this.fetchSteamValue();
        await this.fetchUltrasonicValue();
        await this.fetchTemperatureValue();
        await this.fetchHumidityValue();
        await this.fetchDewPointValue();
        await this.fetchSoilHumadityValue();
      },
  };

  </script>
  
  <style scoped>
  .card-container {
  display: grid;
  grid-template-columns: repeat(3, 1fr); /* Three cards per row */
  gap: 10px; /* Smaller gap between cards */
}

  .toggle-container {
  margin-top: 30px;
  display: flex;
  align-items: flex-start; /* Align switches to the left */
  gap: 20px; /* Add spacing between switches */
}
    .controls-container {
    margin-top: 30px;
    display: flex;
    gap: 20px;
    align-items: flex-start; /* Align switches to the left */
    }
  </style>
  