<template>
    <div>
      <h1>Main Panel</h1>
      <p>Sensors:</p>
      <div class="card-container">
        <SensorCard 
          title="HUMIDITY" 
          value="36.6%" 
          icon="💧" 
          color="blue" 
          @dblclick="navigateToDetails('HUMIDITY')"/>
        <SensorCard 
          title="ILLUMINATION" 
          value="739lm" 
          icon="🌞" 
          color="red" 
          @dblclick="navigateToDetails('ILLUMINATION')"/>
        <SensorCard 
          title="TEMPERATURE" 
          value="21.7°C" 
          icon="🌡️" 
          color="orange" 
          @dblclick="navigateToDetails('TEMPERATURE')"/>
        <SensorCard 
          title="STEAM" 
          value="67%" 
          icon="🌤️" 
          color="blue" 
          @dblclick="navigateToDetails('STEAM')"/>
        <SensorCard 
          title="DEWPOINT" 
          value="21.8°C" 
          icon="💦" 
          color="red" 
          @dblclick="navigateToDetails('DEWPOINT')"/>
        <SensorCard 
          title="SOILHUMADITY" 
          value="87%" 
          icon="🌱" 
          color="orange" 
          @dblclick="navigateToDetails('SOILHUMADITY')"/>
        <SensorCard 
          title="WATERLEVEL" 
          value="25%" 
          icon="🌊" 
          color="blue" 
          @dblclick="navigateToDetails('WATERLEVEL')"/>
        <SensorCard 
          title="ULTRASONIC" 
          value="3m" 
          icon="🔊" 
          color="red" 
          @dblclick="navigateToDetails('ULTRASONIC')"/>
        <SensorCard 
          title="PHOTORESISTOE" 
          value="65" 
          icon="📷" 
          color="orange" 
          @dblclick="navigateToDetails('PHOTORESISTOE')"/>
      </div>

      <p>Controllers:</p>
      <div class="toggle-container">
            <ToggleSwitch label="Passive Buzzer" />
            <ToggleSwitch label="LED" />
            <ToggleSwitch label="Relay Module" />
            <ToggleSwitch label="Servo" />
      </div>

      <div class="controls-container">
            <RangeSlider label="Fan" />
            <ButtonStatus label="Button" />
            <ButtonStatus label="PIR" />
      </div>

    </div>
  </template>
  
  <script>
  import SensorCard from './SensorCard.vue';
  import ToggleSwitch from './ToggleSwitch.vue';
  import RangeSlider from './RangeSlider.vue';
  import ButtonStatus from './ButtonStatus.vue';
  
  export default {
    name: "HomePage",
    components: {
      SensorCard,
      ToggleSwitch,
      RangeSlider,
      ButtonStatus,
    },
    methods: {
    navigateToDetails(title) {
      this.$router.push(`/sensor/${title}`); // Navigate to the sensor details page
    },
    }
  };
  </script>
  
  <style scoped>
  .card-container {
  display: grid;
  grid-template-columns: repeat(3, 1fr); /* Three cards per row */
  gap: 10px; /* Smaller gap between cards */
}

  .toggle-container {
  margin-top: 30px;
  display: flex;
  align-items: flex-start; /* Align switches to the left */
  gap: 20px; /* Add spacing between switches */
}
    .controls-container {
    margin-top: 30px;
    display: flex;
    gap: 20px;
    align-items: flex-start; /* Align switches to the left */
    }
  </style>
  