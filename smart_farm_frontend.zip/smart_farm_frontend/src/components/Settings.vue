
<template>
    <div>
      <h1>Settings</h1>
      <p></p>
    </div>
  </template>
  
  <script>
  /* eslint-disable */
  export default {
    name: "SettingsPage",
  };
  </script>
  
  <style scoped>
  </style>
  