<template>
  <div class="sensor-details">
    <h1>{{ title }}</h1>
    <div class="chart-container">
      <p>Historical Data</p>
      <apexchart type="line" :options="chartOptions" :series="chartSeries" />
    </div>
    <button @click="goHome">Return to Home</button>
  </div>
</template>

<script>
import VueApexCharts from "vue3-apexcharts";

export default {
  name: "SensorDetails",
  components: {
    apexchart: VueApexCharts,
  },
  data() {
    return {
      // Static data for each sensor
      sensorData: {
        HUMIDITY: [30, 35, 40, 45, 50, 55, 60],
        ILLUMINATION: [100, 200, 300, 400, 500, 600, 700],
        TEMPERATURE: [20, 22, 24, 26, 28, 30, 32],
        STEAM:[0.66,0.99,0.76,0.44,0.77],
        DEWPOINT:[23,34,56,34,23,22],
        SOILHUMADITY: [23,34,56,34,23,22],
        WATERLEVEL: [23,34,56,34,23,22],
        ULTRASONIC: [23,34,56,34,23,22],
        PHOTORESISTOE: [23,34,56,34,23,22],
      },
      chartSeries: [], // Data for the chart
      chartOptions: {
        chart: {
          height: 300,
          type: "line",
        },
        xaxis: {
          categories: [], // X-axis labels (will be populated dynamically)
        },
        title: {
          text: "",
          align: "center",
        },
        colors: ["#2d6d92"],
      },
    };
  },
  computed: {
    title() {
      return this.$route.params.title || "Sensor Details"; // Get the title dynamically
    },
  },
  methods: {
    goHome() {
      this.$router.push("/home"); // Navigate back to Home
    },
    updateChartData() {
      const dataArray = this.sensorData[this.title];
      if (dataArray) {
        // Update the chart series and options
        this.chartSeries = [
          {
            name: `${this.title} Data`,
            data: dataArray,
          },
        ];
        this.chartOptions.xaxis.categories = Array.from(
          { length: dataArray.length },
          (_, i) => `Point ${i + 1}`
        );
        this.chartOptions.title.text = `${this.title} Historical Data`;
      } else {
        console.error(`No data found for ${this.title}`);
      }
    },
  },
  mounted() {
    this.updateChartData(); // Initialize chart data on mount
  },
};
</script>

<style scoped>
.sensor-details {
  padding: 20px;
  text-align: center;
}

.chart-container {
  margin: 20px auto;
  width: 80%;
  height: 400px; /* Adjust the height for the chart */
  background: #f0f0f0;
  padding: 20px;
  border-radius: 8px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

button {
  margin-top: 20px;
  background-color: #2d6d92;
  color: white;
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

button:hover {
  background-color: #1e4e68;
}
</style>
