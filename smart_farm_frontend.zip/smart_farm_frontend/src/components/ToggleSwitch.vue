<template>
    <div class="toggle-switch">
      <h3>{{ label }}</h3>
      <div class="switch-container" @click="toggle">
        <div class="toggle-button" :class="{ on: isOn }"></div>
        <span>{{ isOn ? 'ON' : 'OFF' }}</span>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    name: "ToggleSwitch",
    props: {
      label: {
        type: String,
        default: "Passive Buzzer",
      },
    },
    data() {
      return {
        isOn: false, // Default state is OFF
      };
    },
    methods: {
      toggle() {
        this.isOn = !this.isOn; // Toggle the state
      },
    },
  };
  </script>
  
  <style scoped>
  .toggle-switch {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    background-color: #2d6d92; /* Background color */
    color: white;
    border-radius: 8px;
    padding: 20px;
    width: 150px;
    height: 150px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
  }
  
  .switch-container {
    display: flex;
    align-items: center;
    justify-content: space-between;
    width: 100%;
    margin-top: 20px;
    cursor: pointer;
  }
  
  .toggle-button {
    width: 50px;
    height: 25px;
    background-color: #ffd369;
    border-radius: 15px;
    position: relative;
    transition: all 0.3s ease;
  }
  
  .toggle-button::after {
    content: "";
    position: absolute;
    top: 2px;
    left: 2px;
    width: 20px;
    height: 20px;
    background-color: white;
    border-radius: 50%;
    transition: all 0.3s ease;
  }
  
  .toggle-button.on {
    background-color: #64dd17;
  }
  
  .toggle-button.on::after {
    left: 25px;
  }
  
  .switch-container span {
    font-weight: bold;
    font-size: 16px;
  }
  </style>
  