<template>
  <div class="range-slider">
    <h3>{{ label }}</h3>
    <div class="slider-container">
      <input 
        type="range" 
        min="0" 
        max="100" 
        step="25" 
        v-model.number="sliderValue" 
        @input="adjustToClosestValue" 
      />
      <div class="slider-value">
        {{ sliderValue }}%
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "RangeSlider",
  props: {
    label: {
      type: String,
      default: "Slider",
    },
    defaultValue: {
      type: Number,
      default: 50, // Default slider position
    },
  },
  data() {
    return {
      sliderValue: this.defaultValue,
      allowedValues: [0, 25, 50, 75, 100], // Allowed positions
    };
  },
  methods: {
    adjustToClosestValue() {
      // Find the closest allowed value
      const closestValue = this.allowedValues.reduce((prev, curr) =>
        Math.abs(curr - this.sliderValue) < Math.abs(prev - this.sliderValue)
          ? curr
          : prev
      );
      this.sliderValue = closestValue; // Snap slider to the closest allowed value
      this.updateValue(); // Emit the updated value
    },
    updateValue() {
      this.$emit("update", this.sliderValue); // Emit the value for external use
    },
  },
};
</script>

<style scoped>
.range-slider {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  background-color: #2d6d92;
  color: white;
  border-radius: 8px;
  padding: 20px;
  width: 150px;
  height: 150px;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
}

.slider-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-top: 10px;
}

input[type="range"] {
  -webkit-appearance: none;
  appearance: none;
  width: 100%;
  height: 5px;
  background: #ddd;
  outline: none;
  border-radius: 5px;
  border: 1px solid #333;
}

input[type="range"]::-webkit-slider-thumb {
  -webkit-appearance: none;
  appearance: none;
  width: 20px;
  height: 20px;
  background: #008cba;
  border-radius: 50%;
  cursor: pointer;
}

input[type="range"]::-moz-range-thumb {
  width: 20px;
  height: 20px;
  background: #008cba;
  border-radius: 50%;
  cursor: pointer;
}

.slider-value {
  margin-top: 5px;
  font-size: 16px;
  font-weight: bold;
}
</style>
