<template>
  <div class="button-status">
    <h3>{{ label }}</h3>
    <div class="status-container">
      <span>{{ currentTime }}</span>
      <span>{{ status }}</span>
    </div>
  </div>
</template>

<script>
export default {
  name: "ButtonStatus",
  props: {
    label: {
      type: String,
      default: "Button",
    },
  },
  data() {
    return {
      currentTime: new Date().toLocaleTimeString(), // Local time
      stateMap: {
        Button: ["Pressed", "Released"], // States for Button
        PIR: ["Activated", "Inactivated"], // States for PIR
      },
      currentIndex: 0, // Default index for the first state
    };
  },
  computed: {
    // Determine the states dynamically based on the label
    states() {
      return this.stateMap[this.label] || ["Unknown", "Unknown"]; // Fallback to "Unknown" if no matching label
    },
    // Display the current state
    status() {
      return this.states[this.currentIndex];
    },
  },
  methods: {
    // Update the state externally (e.g., from IoT data)
    updateState(newIndex) {
      if (newIndex >= 0 && newIndex < this.states.length) {
        this.currentIndex = newIndex;
      }
    },
  },
  mounted() {
    // Update the current time every second
    setInterval(() => {
      this.currentTime = new Date().toLocaleTimeString();
    }, 1000);

    // Simulate state changes for testing purposes
    setInterval(() => {
      this.currentIndex = (this.currentIndex + 1) % this.states.length; // Cycle through states
    }, 5000);
  },
};
</script>

<style scoped>
.button-status {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  background-color: #2d6d92; /* Background color */
  color: white;
  border-radius: 8px;
  padding: 20px;
  width: 150px;
  height: 150px;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
}

.status-container {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  margin-top: 10px;
}

.status-container span:last-child {
  text-transform: uppercase; /* Display state in uppercase */
  font-weight: bold;
  margin-top: 10px;
}
</style>
