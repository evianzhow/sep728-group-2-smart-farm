<template>
  <div class="rules-page">
    <h1>Automation Rules</h1>
    
    <!-- Add Rule Section -->
    <div class="add-rule">
      <h2>Add a Rule</h2>
      <form @submit.prevent="saveRule">
        <!-- Rule Name -->
        <div class="form-group">
          <label for="ruleName">Rule Name:</label>
          <input
            id="ruleName"
            type="text"
            v-model="newRule.name"
            placeholder="Input Rule Name"
            required
          />
        </div>

        <!-- Trigger Sensor -->
        <div class="form-group">
          <label for="triggerSensor">Trigger Sensor:</label>
          <select id="triggerSensor" v-model="newRule.sensor" required>
            <option value="" disabled>Select Sensor</option>
            <option value="SteamValue">Steam - Value</option>
            <option value="SteamPercentage">Steam - Percentage</option>
            <option value="DHT11Humidity">DHT11 - Humidity</option>
            <option value="DHT11TemperatureCelsius">DHT11 - Temperature(Celsius)</option>
            <option value="DHT11TemperatureFahrenhei">DHT11 - Temperature(Fahrenhei)</option>
            <option value="DHT11TemperatureKelvin">DHT11 - Temperature(Kelvin)</option>
            <option value="DHT11DewPointCelsius">DHT11 - DewPoint(Celsius)</option>
            <option value="SoilValue">Soil - Value</option>
            <option value="SoilPercentage">Soil - Percentage</option>
            <option value="WaterValue">Water - Value</option>
            <option value="WaterPercentage">Water - Percentage</option>
            <option value="UltrasonicDistance">Ultrasonic - Distance</option>
            <option value="LightValue">Light - Value</option>
            <option value="LightPercentage">Light - Percentage</option>
            <option value="Button">Button</option>
            <option value="PIR">PIR</option>
            <option value="RelayLED">Relay/LED</option>
            <option value="Servo">Servo</option>
          </select>
        </div>

        <!-- Type -->
        <div class="form-group">
          <label for="type">Type:</label>
          <select id="type" v-model="newRule.type" @change="resetType" required>
            <option value="" disabled>Select Type</option>
            <option value="Threshold">Threshold</option>
            <option value="Event">Event</option>
          </select>
        </div>

        <!-- Operator and Value -->
        <div class="form-group">
          <label for="operator">Operation:</label>
          <select
            id="operator"
            v-model="newRule.operator"
            :disabled="!newRule.type"
            required
          >
            <option v-for="op in operators" :key="op" :value="op">{{ op }}</option>
          </select>
          <input
            id="thresholdValue"
            type="number"
            v-model="newRule.thresholdValue"
            :disabled="newRule.type === 'Event'"
            placeholder="Input Threshold Value"
          />
        </div>

        <!-- Linked Controller -->
        <div class="form-group">
          <label for="linkedController">Linked Controller:</label>
          <select
            id="linkedController"
            v-model="newRule.controller"
            @change="updateActions"
            required
          >
            <option value="" disabled>Select Controller</option>
            <option value="OFan">Fan</option>
            <option value="OBuzzer">Buzzer</option>
            <option value="ORelay">Relay</option>
            <option value="OLED">LED</option>
            <option value="OServo">Servo</option>
            <option value="OLCD">LCD</option>
          </select>
        </div>
        <div class="form-group">
          <label for="linkedAction">Action:</label>
          <select id="linkedAction" v-model="newRule.action" required>
            <option value="" disabled>Select Action</option>
            <option v-for="action in actions" :key="action" :value="action">
              {{ action }}
            </option>
          </select>
        </div>

        <!-- Save and Cancel Buttons -->
        <div class="form-buttons">
          <button type="submit" class="save-btn">Save</button>
          <button type="button" class="cancel-btn" @click="resetForm">Cancel</button>
        </div>
      </form>
    </div>

    <!-- Existing Rules Section -->
    <div class="existing-rules">
      <h2>Existing Rules</h2>
      <table v-if="rules.length > 0">
        <thead>
          <tr>
            <th>Rule Name</th>
            <th>Trigger Sensor</th>
            <th>Type</th>
            <th>Operator</th>
            <th>Threshold/Action</th>
            <th>Controller</th>
            <th>Action</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(rule, index) in rules" :key="index">
            <td>{{ rule.name }}</td>
            <td>{{ rule.sensor }}</td>
            <td>{{ rule.type }}</td>
            <td>{{ rule.operator }}</td>
            <td>{{ rule.type === 'Threshold' ? rule.thresholdValue : rule.operator }}</td>
            <td>{{ rule.controller }}</td>
            <td>{{ rule.action }}</td>
            <td>
              <button @click="deleteRule(index)">Delete</button>
            </td>
          </tr>
        </tbody>
      </table>
      <p v-else>No existing rules found.</p>
    </div>
  </div>
</template>

<script>
/* eslint-disable */
export default {
  name: "Rules",
  data() {
    return {
      newRule: {
        name: "",
        sensor: "",
        type: "",
        operator: "",
        thresholdValue: null,
        controller: "",
        action: "",
      },
      rules: [], // Store existing rules
      actions: [], // Dynamically updated actions based on controller
    };
  },
  computed: {
    operators() {
      if (this.newRule.type === "Threshold") {
        return [">=", "<=", "==",">","<","!="]; // Threshold operators
      } else if (this.newRule.type === "Event") {
        return ["ON", "OFF"]; // Event operators
      }
      return [];
    },
  },
  methods: {
    async loadRules() {
    // Fetch rules from the backend
    try {
      const response = await fetch("http://localhost:3001/api/rules");
      this.rules = await response.json();
    } catch (error) {
      console.error("Failed to load rules:", error);
    }
  },
  async deleteRule(index) {
    // Remove rule locally
    this.rules.splice(index, 1);

    // Send updated rules to the backend
    try {
      await fetch("http://localhost:3001/api/rules", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(this.rules),
      });
    } catch (error) {
      console.error("Failed to delete rule:", error);
    }
  },

    resetType() {
      // Clear operator and threshold value when type changes
      this.newRule.operator = "";
      this.newRule.thresholdValue = null;
    },
    updateActions() {
    // Dynamically update actions based on selected controller
      switch (this.newRule.controller) {
        case "OFan":
          this.actions = ["0S", "5S", "10S", "30S"];
          break;
        case "OBuzzer":
          this.actions = ["0%", "25%", "50%", "75%", "100%"];
          break;
        case "ORelay":
        case "OLED": // Both Relay and LED have the same actions
          this.actions = ["Active(ON)", "Inactive(OFF)"];
          break;
        case "OServo":
          this.actions = ["Open", "Half Open", "Closed"];
          break;
        case "OLCD":
          this.actions = ["5S", "10S"];
          break;
        default:
          this.actions = []; // Fallback for unknown controllers
      }
    this.newRule.action = ""; // Reset action when controller changes
  },
    async saveRule() {
      // Add the new rule to the list of rules
      this.rules.push({ ...this.newRule });
      this.resetForm(); // Clear the form

          try {
          await fetch("http://localhost:3001/api/rules", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(this.rules),
          });
          this.resetForm();
        } catch (error) {
          console.error("Failed to save rules:", error);
        }

    },
    

    resetForm() {
      // Reset the form to its initial state
      this.newRule = {
        name: "",
        sensor: "",
        type: "",
        operator: "",
        thresholdValue: null,
        controller: "",
        action: "",
      };
      this.actions = [];
    },
  },
  mounted() {
    // Correct placement of mounted hook
    this.loadRules();
  },
};
</script>

<style scoped>
.rules-page {
  padding: 20px;
  max-width: 800px;
  margin: 0 auto;
  font-family: Arial, sans-serif;
}

h1, h2 {
  color: #2d6d92;
}

form {
  display: flex;
  flex-direction: column;
  gap: 15px;
  margin-bottom: 20px;
}

.form-group {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 5px;
}

input, select {
  width: 100%;
  padding: 8px;
  border: 1px solid #ddd;
  border-radius: 4px;
}

input:disabled, select:disabled {
  background-color: #f0f0f0;
  cursor: not-allowed;
}

.form-buttons {
  display: flex;
  gap: 10px;
}

.save-btn {
  background-color: orange;
  color: white;
  border: none;
  padding: 10px 20px;
  border-radius: 5px;
  cursor: pointer;
}

.save-btn:hover {
  background-color: darkorange;
}

.cancel-btn {
  background-color: purple;
  color: white;
  border: none;
  padding: 10px 20px;
  border-radius: 5px;
  cursor: pointer;
}

.cancel-btn:hover {
  background-color: darkmagenta;
}

.existing-rules ul {
  list-style-type: none;
  padding: 0;
}

.existing-rules li {
  background-color: #f9f9f9;
  margin: 5px 0;
  padding: 10px;
  border-radius: 4px;
}
</style>
