<template>
    <div>
      <h1>Automation Rules</h1>
      <p></p>
    </div>
  </template>
  
  <script>
  /* eslint-disable */
  export default {
    name: "RulesPage",
  };
  </script>
  
  <style scoped>
  </style>
  