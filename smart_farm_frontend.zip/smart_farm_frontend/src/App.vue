<!-- cd smart_farm_frontend-->
<!-- npm run serve -->
<!---& "C:\Program Files\Google\Chrome\Application\chrome.exe" --disable-web-security --user-data-dir="C:\chrome-dev-disabled-cors"-->
<template>
  <div id="app">
    
    <div class="sidebar">
      <router-link to="/home">Home</router-link>
      <router-link to="/rules">Rules</router-link>
      <router-link to="/settings">Settings</router-link>
    </div>
    
    <div class="content">
      <router-view />
    </div>
  </div>
</template>

<script>
/* eslint-disable */
import axios from "axios";

export default {
  name: "App",
  data() {
    return {
      authToken: "", 
    };
  },
  methods: {
    async fetchAuthToken() {
      try {
        const response = await axios.post(
          "https://gorgeous-glowworm-definite.ngrok-free.app/login",
          {
            username: "admin", // fixed username
            password: "securepassword", // fixed password
          }
        );
        this.authToken = response.data.token;
        console.log("Token fetched:", this.authToken);
        localStorage.setItem("authToken", this.authToken); 
      } catch (error) {
        console.error("Failed to fetch token:", error);
        this.authToken = null;
      }
    },
    async getAuthToken() {
      
      const storedToken = localStorage.getItem("authToken");
      if (storedToken) {
        console.log("Token loaded from localStorage:", storedToken);
        this.authToken = storedToken;
      } else {
        
        await this.fetchAuthToken();
      }
    },
  },
    provide() {
        return {
          getAuthToken: () => this.authToken, 
        };
        },
    async mounted() {
        const storedToken = localStorage.getItem("authToken");
      if (storedToken) {
        console.log("Token loaded from localStorage:", storedToken);
        this.authToken = storedToken;
      } else {
        await this.fetchAuthToken(); 
      } 
      },
};
</script>

<style scoped>

#app {
  display: flex;
  height: 100vh;
}

.sidebar {
  background-color: #f4f4f4;
  padding: 20px;
  width: 200px;
  display: flex;
  flex-direction: column;
}

.sidebar a {
  text-decoration: none;
  color: white;
  background-color: #4caf50;
  padding: 10px 15px;
  margin: 5px 0;
  text-align: center;
  border-radius: 5px;
}

.sidebar a:hover {
  background-color: #45a049;
}

.content {
  flex: 1;
  padding: 20px;
  overflow-y: auto;
}
</style>
